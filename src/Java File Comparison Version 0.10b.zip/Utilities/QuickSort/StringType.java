package Utilities.QuickSort;

public class StringType implements QuickSortInterface
{
	public static String[] execute(String[] list)
	{
		return null;
	}
}
