package Utilities.QuickSort;

public interface QuickSortInterface 
{
	//public abstract String[] quickSort(); 
}
