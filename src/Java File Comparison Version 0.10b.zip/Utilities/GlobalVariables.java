package Utilities;
public class GlobalVariables 
{
	public static String leftFolderName;
	public static String rightFolderName;
	public static String mainReportName;
	
//	public static String mainFolderPath;
	
	public static String executionDate;
	
	//Executable Environment:
	public static String executableDirectroy;
	public static String RESOURCE_FILEPATH;
	public static String HTML_RESOURCE_FILEPATH;
	public static String SETTING_RESOURCE_FILEPATH;
	
	//input Variables
	public static String GlobalSettingFilePath;
	public static String FileCompSettingFilePath;
	public static String LanguageFilePath;
	
	public static int failureCount;
	
	public static long programStartTime;
}
