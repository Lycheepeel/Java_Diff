package Settings;

public class global {

}
